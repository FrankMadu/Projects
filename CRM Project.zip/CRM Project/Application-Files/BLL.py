from DAL import DataAccessLayer

class BusinessLogicLayer:
    def __init__(self):
        self.dal = DataAccessLayer()

    def add_new_product(self, name, price, stock_quantity):
        if not name or not isinstance(price, (int, float)) or not isinstance(stock_quantity, int):
            return "Error: Invalid input data. Please provide a valid product name, price, and stock quantity."
        try:
            args = [name, price, stock_quantity]
            result = self.dal.use_modify_procedure('AddNewProduct', args)
            if result is None:  # If the result is None, it indicates success
                return "Product added successfully."
            else:
                print(f"Error from procedure: {result}")
                return result
        except Exception as e:
            print(f"Exception occurred: {str(e)}")
            return f"Error: {str(e)}"

    def update_customer_address(self, customer_id, new_address):
        try:
            args = [customer_id, new_address]
            result = self.dal.use_modify_procedure('UpdateCustomerAddress', args)
            if result is None:  # If the result is None, it indicates success
                return "Customer address updated successfully."
            else:
                print(f"Error from procedure: {result}")
                return result
        except Exception as e:
            print(f"Exception occurred: {str(e)}")
            return f"Error: {str(e)}"
        
    def get_user_info(self, user_id):
        user = self.dal.searchUsersbyID(user_id)
        if user:
            if 'error' in user:
                return f"Error fetching user: {user['error']}"
            return (
                f"User ID: {user['id']}\n"
                f"Name: {user['first_name']} {user['last_name']}\n"
                f"Email: {user['email']}\n"
                f"Date of Birth: {user['date_of_birth']}\n"
                f"Phone Number: {user['phone_number']}\n"
                f"Address: {user['address']}\n"
                f"Account Creation Date: {user['account_creation_date']}"
            )
        else:
            return "User not found or no information available."
        
    def get_all_products(self):
        try:
            return self.dal.get_all_products()
        except Exception as e:
            return f"Error: {str(e)}"

    def get_customer_info(self, customer_id):
        try:
            args = [customer_id]
            result = self.dal.use_read_procedure('searchCustomersbyID', args)
            if result and isinstance(result, list) and len(result) > 0:
                customer_info = result[0][0]  # Stores data in a tuple
                return (
                    f"Customer ID: {customer_info[0]}\n"
                    f"Name: {customer_info[1]} {customer_info[2]}\n"
                    f"Email: {customer_info[3]}\n"
                    f"Date of Birth: {customer_info[4]}\n"
                    f"Phone Number: {customer_info[5]}\n"
                    f"Address: {customer_info[6]}\n"
                    f"Account Creation Date: {customer_info[7]}"
                )
            else:
                return "Customer not found or no information available."
        except Exception as e:
            print(f"Exception occurred: {str(e)}")
            return f"Error: {str(e)}"