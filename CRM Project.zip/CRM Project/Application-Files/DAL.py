import mysql.connector
from mysql.connector import errorcode

class DataAccessLayer:
    def __init__(self):
        try:
            self.read_cnx = mysql.connector.connect(
                host='127.0.0.1',
                user='read_user',
                password='read123',
                database='CRM',
                autocommit=True  # Enable autocommit for read connection
            )
            self.modify_cnx = mysql.connector.connect(
                host='127.0.0.1',
                user='modify_user',
                password='modify123',
                database='CRM',
                autocommit=True  # Enable autocommit for modify connection
            )
        except mysql.connector.Error as err:
            print(f"Failed to connect to database: {err}")
            raise

    def use_read_procedure(self, procedure_name, args):
        try:
            read_cursor = self.read_cnx.cursor()
            read_cursor.callproc(procedure_name, args)
            results = []
            for result in read_cursor.stored_results():
                results.append(result.fetchall())
            read_cursor.close()
            return results if results else None
        except mysql.connector.Error as err:
            print(f"Error executing read procedure {procedure_name}: {err}")
            return {"error": str(err)}

    def use_modify_procedure(self, procedure_name, args):
        try:
            modify_cursor = self.modify_cnx.cursor()
            modify_cursor.callproc(procedure_name, args)
            results = []
            for result in modify_cursor.stored_results():
                results.append(result.fetchall())
            modify_cursor.close()
            return results if results else None
        except mysql.connector.Error as err:
            print(f"Error executing modify procedure {procedure_name}: {err}")
            return {"error": str(err)}

    def searchUsersbyID(self, user_id):
        try:
            read_cursor = self.read_cnx.cursor()
            read_cursor.callproc('searchUsersbyID', (user_id,))
            results = []
            for result in read_cursor.stored_results():
                results.append(result.fetchone())
            read_cursor.close()
            if results and results[0]:
                user = results[0]
                return {
                    "id": user[0],
                    "first_name": user[1],
                    "last_name": user[2],
                    "email": user[3],
                    "date_of_birth": user[4],
                    "phone_number": user[5],
                    "address": user[6],
                    "account_creation_date": user[7]
                }
            else:
                return {"error": "User not found."}
        except mysql.connector.Error as err:
            print(f"Error fetching user by ID {user_id}: {err}")
            return {"error": str(err)}
        
    def get_all_products(self):
        try:
            read_cursor = self.read_cnx.cursor()
            read_cursor.execute("SELECT * FROM Products")
            results = read_cursor.fetchall()
            products = []
            for result in results:
                products.append({
                    "id": result[0],
                    "name": result[1],
                    "price": result[2],
                    "stock_quantity": result[3]
                })
            read_cursor.close()
            return products
        except mysql.connector.Error as err:
            print(f"Error fetching products: {err}")
            return {"error": str(err)}
    
    def close(self):
        self.read_cnx.close()
        self.modify_cnx.close()

