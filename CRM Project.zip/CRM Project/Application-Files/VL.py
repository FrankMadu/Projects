import toga
from toga.style.pack import COLUMN, ROW, Pack
import toga.widgets
from BLL import BusinessLogicLayer

#Instantiate Business Logic Layer
bll = BusinessLogicLayer()

class View(toga.App):

    def startup(self):
        self.main_window = toga.MainWindow(title=self.name)

        # Adding product UI
        self.product_name_input = toga.TextInput(placeholder='Enter product name')
        self.product_price_input = toga.TextInput(placeholder='Enter product price')
        self.product_quantity_input = toga.TextInput(placeholder='Enter stock quantity')
        self.add_product_button = toga.Button('Add Product', on_press=self.add_product)

        product_box = toga.Box(
            children=[
                toga.Label('Product Name:'),
                self.product_name_input,
                toga.Label('Product Price:'),
                self.product_price_input,
                toga.Label('Stock Quantity:'),
                self.product_quantity_input,
                self.add_product_button
            ],
            style=Pack(direction=COLUMN, padding=10)
        )

        self.product_status_label = toga.Label('')
        product_status_box = toga.Box(
            children=[self.product_status_label],
            style=Pack(direction=COLUMN, padding=10)
        )

        # Side window to show current products
        self.products_list = toga.Table(
            headings=['ID', 'Name', 'Price', 'Stock Quantity'],
            data=self.get_products_data(),
            style=Pack(flex=1)  # Allow the products list to expand
        )

        products_list_box = toga.Box(
            children=[self.products_list],
            style=Pack(direction=COLUMN, padding=10, flex=1)
        )

        # Main layout
        main_content_box = toga.Box(
            children=[
                products_list_box,
                product_box,
                product_status_box
            ],
            style=Pack(direction=COLUMN, padding=10)
        )

        main_layout = toga.Box(
            children=[products_list_box, main_content_box],
            style=Pack(direction=ROW, padding=10)
        )

        self.main_window.content = main_layout
        self.main_window.show()

    def add_product(self, widget):
        name = self.product_name_input.value
        price = self.product_price_input.value
        quantity = self.product_quantity_input.value

        result = bll.add_new_product(name, price, quantity)
        self.product_status_label.text = result
        self.products_list.data = self.get_products_data()  # Refresh product list

    def get_products_data(self):
        products = bll.get_all_products()
        if isinstance(products, list):
            return [(product['id'], product['name'], product['price'], product['stock_quantity']) for product in products]
        else:
            return []

def main():
    return View("CSC6302 CRM", "User Views App")

if __name__ == "__main__":
    main().main_loop()
