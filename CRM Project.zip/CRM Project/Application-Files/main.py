from BLL import BusinessLogicLayer
import PL as PresentationLayer

def main():
    # Initialize BusinessLogicLayer
    bll = BusinessLogicLayer()

    # Call presentation functions
    while True:
        print("\nSelect an option:")
        print("1. Add New Product")
        print("2. Update Customer Address")
        print("3. Get User Info")
        print("4. Get Customer Info")
        print("5. Get All Products")
        print("6. Exit")

        choice = input("\nEnter choice: ")
        print()

        if choice == '1':
            PresentationLayer.add_product(bll)
        elif choice == '2':
            PresentationLayer.update_customer_address(bll)
        elif choice == '3':
            PresentationLayer.get_user_info(bll)
        elif choice == '4':
            PresentationLayer.get_customer_info(bll)
        elif choice == '5':
            products = bll.get_all_products()
            if isinstance(products, dict):  # Check if there's an error
                print("Error fetching products.")
            else:
                for product in products:
                    print(f"Product ID: {product['id']}, Product Name: {product['name']}, Price: {product['price']}, Stock Quantity: {product['stock_quantity']}")
        elif choice == '6':
            print('Thank you! Please try again soon.')
            break
        else:
            print("Invalid choice. Please try again.")

    # Close the DAL connection
    bll.dal.close()

# Call Main Function
if __name__ == "__main__":
    main()


