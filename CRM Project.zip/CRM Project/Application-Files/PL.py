from BLL import BusinessLogicLayer

def add_product(bll):
    try:
        name = input("Enter product name: ")
        price = float(input("Enter product price: "))
        stock_quantity = int(input("Enter stock quantity: "))
        
        result = bll.add_new_product(name, price, stock_quantity)
        print(result)
    
    except ValueError:
        print("Invalid input. Please ensure that the price is a number and the stock quantity is an integer. Please try again with valid information.")
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")

def update_customer_address(bll):
    while True:
        try:
            customer_id = int(input("Enter customer ID: "))
            customer_info = bll.get_customer_info(customer_id) # Used to determine if customer exists
            
            if "Error" in customer_info or customer_info == "Customer not found or no information available.":
                print(customer_info)
                print("Customer ID not found. Please try again with a valid customer ID.\n")
                continue
            new_address = input("Enter new address: ")
            
            result = bll.update_customer_address(customer_id, new_address)
            print(result)
            break
        except ValueError:
            print("Invalid input. Please enter a valid numeric customer ID.")
        except Exception as e:
            print(f"An unexpected error occurred: {str(e)}")
            

def get_user_info(bll):
    while True:
        try:
            user_id = int(input("Enter user ID: "))
            result = bll.get_user_info(user_id)
            
            if "Error" in result or result == "User not found.":
                print(result)
                print("User not found. Please try again.\n")
            else:
                print(result)
                break

        except ValueError:
            print("Invalid input. Please enter a valid numeric user ID.")

def get_customer_info(bll):
    while True:
        try:
            customer_id = int(input("Enter customer ID: "))
            result = bll.get_customer_info(customer_id)
            
            if "Error" in result or result == "Customer not found or no information available.":
                print(result)
                print("Customer not found. Please try again.\n")
            else:
                print(result)
                break

        except ValueError:
            print("Invalid input. Please enter a valid numeric customer ID.")