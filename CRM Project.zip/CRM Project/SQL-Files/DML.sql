-- Note: Run Functionality.sql before running this file or else there will be an error
-- Adds Data into the tables
INSERT INTO Users (first_name, last_name, email, date_of_birth, phone_number, address, date_created) VALUES 
('Frank', 'Madu', 'maduf@merrimack.edu', '1998-06-01', '281-924-1278', '12345 Saint St., New York, NY', '2023-08-23'), 
('Samson', 'Jacobs', 'sjacobs@merrimack.edu', '1998-08-13', '832-361-9235', '12345 Bait St., San Antonio, TX', '2023-11-08'), 
('Rob','Anderson','randerson@merrimack.edu','1998-07-03', '281-924-1360', '12346 Sanders St., Boston, MA', '2024-03-15'),
('Aiden', 'Green', 'aiden.green@example.com', '1985-07-12', '202-555-0111', '123 Maple St, Springfield', CURDATE()),
('Emma', 'Taylor', 'emma.taylor@example.com', '1992-09-25', '303-555-0222', '456 Oak St, Springfield', CURDATE()),
('Lucas', 'Miller', 'lucas.miller@example.com', '1988-03-14', '404-555-0333', '789 Pine St, Springfield', CURDATE()),
('Olivia', 'Brown', 'olivia.brown@example.com', '1995-11-30', '505-555-0444', '101 Elm St, Springfield', CURDATE()),
('Noah', 'Davis', 'noah.davis@example.com', '1990-05-16', '606-555-0555', '202 Birch St, Springfield', CURDATE());

INSERT INTO Products (product_name, price, stock_quantity) VALUES ('Apple', 7.50, 100), ('Orange', 8, 70), ('Banana', 6.70, 250), ('Mango', 10, 50), ('Broccoli', 5, 100), ('Carrots', 4, 160), ('Beef', 15, 100), ('Chicken', 13, 100), ('Milk', 3, 100), ('Breat', 2, 500), ('Cookies', 3.25, 200);
INSERT INTO Sales (customer_id, product_id, quantity) VALUES (1, 1, 10), (2, 2, 5), (1, 3, 20);
INSERT INTO Roles (role_type) VALUES ('Trainer'), ('Sales'), ('Marketing'), ('Administrator'), ('Support');

INSERT INTO Customers (first_name, last_name, email, date_of_birth, phone_number, address, date_created) VALUES 
('Dan', 'Jackson', 'danjsolo@hotmail.com', '1998-09-01', '302-834-1831', '12345 Brine Ct., New York, NY', '2023-10-23'),
('Jack', 'Hendrick', 'jhendrees@yahoo.com', '1995-10-13', '713-743-3994', '12345 Turnout Ln., Forth Worth, TX', '2023-11-08'),
('Bob','Andrews','bandrews@gmail.com','1990-11-03', '281-743-8934', '12346 Sanders St., North Andover, MA', '2024-03-15'),
('Alice', 'Smith', 'alice.smith@example.com', '1990-05-15', '555-1234', '123 Elm St, Springfield', CURRENT_DATE()),
('Bob', 'Johnson', 'bob.johnson@example.com', '1985-08-22', '555-5678', '456 Oak St, Springfield', CURRENT_DATE()),
('Carol', 'Williams', 'carol.williams@example.com', '1992-11-30', '555-8765', '789 Pine St, Springfield', CURRENT_DATE()),
('David', 'Brown', 'david.brown@example.com', '1980-03-12', '555-4321', '321 Maple St, Springfield', CURRENT_DATE()),
('Eva', 'Zones', 'eva.jones@example.com', '1995-01-28', '555-1357', '654 Cedar St, Springfield', CURRENT_DATE()),
('Frank', 'Garcia', 'frank.garcia@example.com', '1988-07-04', '555-2468', '987 Birch St, Springfield', CURRENT_DATE()),
('Grace', 'Martinez', 'grace.martinez@example.com', '1991-12-19', '555-3690', '321 Spruce St, Springfield', CURRENT_DATE()),
('Hank', 'Davis', 'hank.davis@example.com', '1983-02-14', '555-2580', '654 Willow St, Springfield', CURRENT_DATE());


INSERT INTO UsersRoles (user_id, role_id) VALUE (1,2), (2,3), (3,1), (1,4), (2,5), (1,1);

INSERT INTO ProductCategories (category_name) VALUES ('Fruit'), ('Vegetable'), ('Meat'), ('Dairy'), ('Bakery');

INSERT INTO ProductCategoryAssignment (product_id, category_id) VALUES (1,1), (2,1), (3,1), (4,1), (5,2), (6,2), (7,3), (8,3), (9,4), (10,5), (11,5);

