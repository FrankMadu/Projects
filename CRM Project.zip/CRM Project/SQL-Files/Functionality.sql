-- Note: Run this file before the DML.sql file
-- Functions
-- Gets the full name of any user

DROP FUNCTION IF EXISTS GetUserFullName;

DELIMITER $$
CREATE FUNCTION GetUserFullName(userId INT)
RETURNS VARCHAR(150)
DETERMINISTIC
BEGIN
    DECLARE fullName VARCHAR(150);
    SELECT CONCAT(first_name, ' ', last_name) INTO fullName
    FROM Users
    WHERE id = userId;
    RETURN fullName;
END $$
DELIMITER ;

-- Calculates the total sales received from any Customer

DROP FUNCTION IF EXISTS GetTotalSales;

DELIMITER $$
CREATE FUNCTION GetTotalSales(customerId INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE totalSales DECIMAL(10,2);
    SELECT SUM(total_cost) INTO totalSales
    FROM Sales
    WHERE customer_id = customerId;
    RETURN IFNULL(totalSales, 0);
END $$
DELIMITER ;

-- Procedures
-- Adds a new product

DROP PROCEDURE IF EXISTS AddNewProduct;

DELIMITER $$
CREATE PROCEDURE AddNewProduct(
    IN p_name VARCHAR(50),
    IN p_price DECIMAL(10,2),
    IN p_stock_quantity INT
)
BEGIN
    INSERT INTO Products (product_name, price, stock_quantity)
    VALUES (p_name, p_price, p_stock_quantity);
END $$
DELIMITER ;


-- Update the customer address

DROP PROCEDURE IF EXISTS UpdateCustomerAddress;

DELIMITER $$
CREATE PROCEDURE UpdateCustomerAddress(
    IN c_id INT,
    IN new_address VARCHAR(255)
)
BEGIN
    UPDATE Customers
    SET address = new_address
    WHERE customer_id = c_id;
END $$
DELIMITER ;

-- Gets information from the users
DROP PROCEDURE IF EXISTS searchUsersbyID;

DELIMITER $$
CREATE PROCEDURE searchUsersbyID(IN user_id INT)
BEGIN
    SELECT id, first_name, last_name, email, date_of_birth, phone_number, address, date_created
    FROM Users
    WHERE id = user_id;
END $$
DELIMITER ;


-- Gets information from the customers
DROP PROCEDURE IF EXISTS searchCustomersbyID;

DELIMITER $$
CREATE PROCEDURE searchCustomersbyID(IN c_id INT)
BEGIN
    SELECT customer_id, first_name, last_name, email, date_of_birth, phone_number, address, date_created
    FROM Customers
    WHERE customer_id = c_id;
END $$
DELIMITER ;


-- Automatically Calculates Sales (Run this before DML file)
DELIMITER $$

CREATE TRIGGER calculate_total_cost
BEFORE INSERT ON Sales
FOR EACH ROW
BEGIN
    DECLARE product_price DECIMAL(10,2);
    
    -- Get the price of the product
    SELECT price INTO product_price
    FROM Products
    WHERE product_id = NEW.product_id;
    
    -- Calculate the total cost
    SET NEW.total_cost = product_price * NEW.quantity;
END; $$

DELIMITER ;