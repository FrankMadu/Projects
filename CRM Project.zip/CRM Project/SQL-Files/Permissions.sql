-- Create Users
DROP USER IF EXISTS 'read_user'@'localhost';
CREATE USER IF NOT EXISTS 'read_user'@'localhost' IDENTIFIED BY 'read123';

DROP USER IF EXISTS 'modify_user'@'localhost';
CREATE USER IF NOT EXISTS 'modify_user'@'localhost' IDENTIFIED BY 'modify123';

-- Create Roles
DROP ROLE IF EXISTS 'read_access';
CREATE ROLE IF NOT EXISTS 'read_access';

DROP ROLE IF EXISTS 'modify_access';
CREATE ROLE IF NOT EXISTS 'modify_access';

-- Grant access to Roles
GRANT SELECT, EXECUTE
ON CRM.*
TO 'read_access';

GRANT INSERT, UPDATE, DELETE, EXECUTE
ON CRM.*
TO 'modify_access';

-- Assign Roles to Users
GRANT 'read_access' TO 'read_user'@'localhost';
GRANT 'modify_access' TO 'modify_user'@'localhost';

SET DEFAULT ROLE 'read_access' TO 'read_user'@'localhost';
SET DEFAULT ROLE 'modify_access' TO 'modify_user'@'localhost';

FLUSH PRIVILEGES;




