/*

Schema Definition
Customer:
	Definition:
	Customers (id: int, first_name: varchar(50), last_name: varchar(100), email: varchar(100), date_created: date, Primary Key: id)

    Primary Key:
    id - used for uniquely identifying customers through incremented integer IDs
	
	Super Keys:
    1. id
    2. first_name
    3. last_name
    4. email
    5. date_created
    6. id, first_name
    7. id, last_name
    8. id, email
    9. id, date_created
    10. first_name, last_name
    11. first_name, email
    12. first_name, date_created
    13. last_name, email
    14. last_name, date_created
    15. email, date_created
    16. etc.
    
    Candidate Key:
    id, email
    
Products:
	Definitions:
    Products (product_id: int, product_name: varchar(50), price: decimal(10,2), stock_quantity: int, Primary Key: product_id)
    
    Primary Key:
    product_id - used for uniquely identifying products through incremented integer IDs
    
    Super Keys:
    1. product_id
    2. product_name
    3. price
    4. stock_quantity
    5. product_id, product_name
    6. product_id, price
    7. product_id, stock_quantity
    8. product_name, price
    9. product_name, stock_quantity
    10. price, stock_quantity
    11. product_id, product_name, price
    12. product_id, product_name, stock_quantity
    13. product_id, price, stock_quantity
    14. product_name, price, stock_quantity
    15. product_id, product_name, price, stock_quantity
    
    Candidate Keys:
    product_id, product_name
    
Sales:
	Definition:
    Sales (sale_id: int, customer_id: int, sale_date: date, total_cost: decimal(10,2), Primary Key: sale_id, Foreign Key: customer_id references Customers(id))

    Primary Key:
    sale_id - used for uniquely idenfity customer sales through incremented integer IDs
	
    Super Keys:
    1. sale_id
    2. customer_id
    3. sale_date
    4. total_cost
    5. sale_id, customer_id
    6. sale_id, sale_date
    7. sale_id, total_cost
    8. customer_id, sale_date
    9. customer_id, total_cost
    10. sale_date, total_cost
    11. sale_id, customer_id, sale_date
    12. sale_id, customer_id, total_cost
    13. sale_id, sale_date, total_cost
    14. customer_id, sale_date, total_cost
    15. sale_id, customer_id, sale_date, total_cost
    
    Candidate Key:
    sale_id
    
*/

/*
All Tables are in Boyce-Codd Normal Form (BCNF) since every non-key attribute is dependent on every primary/candidate key
*/

/*
File Run Order: DDL --> Permissions --> Functionality --> DML --> QueriesCalls
*/

DROP DATABASE IF EXISTS CRM;

-- Creates a Database:
CREATE DATABASE IF NOT EXISTS CRM;

USE CRM;

-- Creates the Relations
-- Relation 1
CREATE TABLE IF NOT EXISTS Users (
id INT AUTO_INCREMENT PRIMARY KEY,
first_name VARCHAR(50) NOT NULL,
last_name VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL UNIQUE,
date_of_birth DATE NOT NULL,
phone_number VARCHAR(20) NOT NULL,
address VARCHAR(255) NOT NULL,
date_created DATE NOT NULL
);

-- Relation 2
CREATE TABLE IF NOT EXISTS Products (
product_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
product_name VARCHAR(50) NOT NULL UNIQUE,
price DECIMAL(10,2) NOT NULL,
stock_quantity INT NOT NULL
);

-- Relation 3
CREATE TABLE IF NOT EXISTS Sales (
sale_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
customer_id INT NOT NULL,
product_id INT NOT NULL,
quantity INT NOT NULL,
sale_date DATE DEFAULT (CURRENT_DATE()),
total_cost DECIMAL(10,2) NOT NULL,
FOREIGN KEY (customer_id) REFERENCES Users(id),
FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Create Indexes
CREATE INDEX idx_products_product_name ON Products (product_name);
CREATE INDEX idx_customer_id ON Sales(customer_id);
CREATE INDEX idx_product_id ON Sales(product_id);

-- Relation 4
CREATE TABLE IF NOT EXISTS Roles (
role_id INT AUTO_INCREMENT PRIMARY KEY,
role_type VARCHAR(50) NOT NULL UNIQUE
);

-- Relation 5
CREATE TABLE IF NOT EXISTS UsersRoles (
user_id INT NOT NULL,
role_id INT NOT NULL,
PRIMARY KEY (user_id, role_id),
FOREIGN KEY (user_id) REFERENCES Users(id),
FOREIGN KEY (role_id) REFERENCES Roles(role_id)
);

-- Relation 6
CREATE TABLE IF NOT EXISTS Customers (
customer_id INT AUTO_INCREMENT PRIMARY KEY,
first_name VARCHAR(50) NOT NULL,
last_name VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL UNIQUE,
date_of_birth DATE NOT NULL,
phone_number VARCHAR(15),
address VARCHAR(255),
date_created DATE NOT NULL
);

-- Relation 7
CREATE TABLE IF NOT EXISTS ProductCategories (
category_id INT AUTO_INCREMENT PRIMARY KEY,
category_name VARCHAR(50) NOT NULL UNIQUE
);

-- Relation 8
CREATE TABLE IF NOT EXISTS ProductCategoryAssignment (
product_id INT NOT NULL,
category_id INT NOT NULL,
PRIMARY KEY (product_id, category_id),
FOREIGN KEY (product_id) REFERENCES Products(product_id),
FOREIGN KEY (category_id) REFERENCES ProductCategories(category_id)
);



