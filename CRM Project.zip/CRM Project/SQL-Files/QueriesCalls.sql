-- Function Calls
-- Function 1 
SELECT id, GetUserFullName(id) AS FullName
FROM Users
WHERE id BETWEEN 1 AND 5;

-- Function 2
SELECT GetTotalSales(1) AS TotalSales;

-- Procedure Calls
-- Procedure 1 (Modify)
CALL AddNewProduct('Turkey', 12, 200);

-- Procedure 2 (Modify)
CALL UpdateCustomerAddress(3, '3750 Hoffman Avenue, Brooklyn, NY 11206');

-- Procedure 3 (Read)
CALL searchUsersbyID(4);

-- Procedure 4 (Read)
CALL searchCustomersbyID(10);


-- Queries
SELECT * FROM Users WHERE last_name like '%a%';
SELECT * FROM Products WHERE price >= 10;

-- Index Queries
EXPLAIN SELECT * FROM Products WHERE product_name = 'Orange';

SHOW INDEX FROM Products;

